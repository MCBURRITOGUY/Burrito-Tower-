STUFF I LIKE TO ADD CUZ WHY NOT


added rank screens
finally finished the 3rd level (city)
added back the boss fight
and yeah that is about it, play the demo :)